# CICD_Java_gradle_application

This application is java spring boot web application  

build tool is ** gradle **

when we build the code using command ```./gradlew build ``` it will generate war file. that war can be placed in tomcat server to see application web page

code is integrated with sonarqube plugin which help us in static code analysis 

``` ./gradlew sonarqube ```